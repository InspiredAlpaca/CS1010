// CS1010 AY2013/4 Semester 1
// PE1 Ex1: tray.c
// Name: 
// Matriculation number: 
// plab-id: 
// Discussion group: 
// Description: 

int main(void) {
	int trayHeight, trayWidth, slabHeight, slabWidth;

	printf("Enter size of tray: ");

	printf("Enter size of slab: ");

	printf("Minimum unused area = "); // incomplete

	printf("Minimum perimeter after folding = "); // incomplete

	return 0;
}

