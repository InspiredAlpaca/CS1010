// CS1010 AY2011/2 Semester 1 
// PE1 Ex2: winners.c
// Name: 
// Matriculation number: 
// plab account-id: 
// Discussion group: 
// Description: 

int main(void)
{
	int factor;       

	printf ("Enter factor-digit: ");
	printf("Enter must-have-digit: ");
	printf("Enter number of participants: ");

	return 0;
}

