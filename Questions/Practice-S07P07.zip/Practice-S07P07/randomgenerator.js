/*
 * This is a JavaScript Scratchpad.
 *
 * Enter some JavaScript, then Right Click or choose from the Execute Menu:
 * 1. Run to evaluate the selected text (Ctrl+R),
 * 2. Inspect to bring up an Object Inspector on the result (Ctrl+I), or,
 * 3. Display to insert the result in a comment after the selection. (Ctrl+L)
 */

var n=20,r=[],m=5;
for(var a=0;a<n;a++) r[a]=a;
for(var a=0;a<n;a++)
{
    var p=Math.floor(Math.random()*(n-a));
    var t=r[a];
    r[a]=r[p];
    r[p]=t;
}
var str="";
for(var a=0;a<n/m;a++)
{
    for(var s=0;s<m;s++)
    {
        str+=r[a*m+s]+"\t";
    }
    str+="\n";
}
str;
