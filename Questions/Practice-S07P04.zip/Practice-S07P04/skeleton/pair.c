// pair.c
#include <stdio.h>

int findPair(int [], int, int, int *, int *);

int main() {
	int size;

	printf("Please enter the number of elements: ");

	//input the elements into array
	printf("Please enter %d integers: ", size);

	printf("Please enter the target sum: ");

	return 0;
}

