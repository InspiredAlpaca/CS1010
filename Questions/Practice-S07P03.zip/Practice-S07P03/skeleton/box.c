// box.c
// To compute the number of boxes with length, width and height
// in the range [lower,upper] whose surface area is larger than
// volume.
#include <stdio.h>

int main(void) {
	int lower, upper;

	printf("Enter lower and upper limits: ");
	scanf("%d %d", &lower, &upper);

	printf("Answer = %d\n");

	return 0;
}

