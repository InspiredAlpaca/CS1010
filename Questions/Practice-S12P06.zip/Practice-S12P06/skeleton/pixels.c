#include <stdio.h>
#define MAX_PIXELS 20

int main(void) {
	int n,   // number of pixels
	    constA, constB, constC, constD;

	scanf("%d %d %d %d %d", &n, &constA, &constB, &constC, &constD);

	return 0;
}

