// CS1010 AY2012/3 Semester 1
// PE1 Ex1: sat.c
// Name: 
// Matriculation number: 
// plab account-id: 
// Discussion group: 
// Description:

int main(void) {

	int verbal, math, writing ; // user's input

	printf("Enter scores: ");

	return 0;

}
