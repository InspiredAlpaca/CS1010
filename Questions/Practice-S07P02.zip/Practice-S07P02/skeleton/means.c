// means.c
// To compute the arithmetic mean and geometric mean of 3 positive integer.
#include <stdio.h>

int main(void) {
	int num1, num2, num3;
	float am, gm;   // am = arithmetic mean; gm = geometric mean

	printf("Enter 3 positive integers: ");

	printf("Arithmetic mean = %.2f\n");
	printf("Geometric mean = %.2f\n");

	return 0;
}


