// CS1010 AY2014/5 Semester 1
// PE1 Ex2: happy.c
// Name: 
// Matriculation number: 
// plab-id: 
// Discussion group: 
// Description: 

int main(void){
	int lower1, upper1, lower2, upper2, number1, number2;

	printf("Enter first range: ");

	printf("Enter second range: ");

	printf("The numbers of happy numbers in the two ranges are: %d %d\n", number1, number2);

	printf("There are more happy numbers in the first range.\n");

	printf("There are more happy numbers in the second range.\n");

	printf("The numbers of happy numbers in both ranges are the same.\n");

	return 0;
}
