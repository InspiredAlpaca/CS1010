// pig_latin.c
#include <stdio.h>

void convert(char [], char []);

int main(void) {

	printf("Enter sentence: ");

	printf("\nConverted: %s\n", converted);

	return 0;
}

// Convert src into pig-latin in dest
void convert(char src[], char dest[]) {

}

