// prize.c
#include <stdio.h>
#define MAX_SIZE 300

typedef struct {
	int id; // The student number
	int scores[MAX_SIZE]; // The test scores of the student
	int prize; // Whether the student has received a prize
} student_t;

int main(void){

	return 0;
}

