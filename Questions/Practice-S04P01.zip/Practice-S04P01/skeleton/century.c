// CS1010 AY2011/2 Semester 1 
// PE1 Ex1: century.c
// Name: 
// Matriculation number: 
// plab account-id: 
// Discussion group: 
// Description:

int main(void)
{
	int year; // user's input

	printf("Enter year: ");

	return 0;
}

