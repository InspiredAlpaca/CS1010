// CS1010 AY2012/3 Semester 1
// PE1 Ex2: ucard.c
// Name: 
// Matriculation number: 
// plab account-id: 
// Discussion group: 
// Description:

int main(void) {
	int uCardNo; 

	printf("Enter uCard Number: ");

	return 0;
}

