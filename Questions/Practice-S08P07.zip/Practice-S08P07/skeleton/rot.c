// rot.c

#include <stdio.h>
#define MAX_LENGTH 80

void encrypt(char [], char []);
void decrypt(char [], char []);

int main(void) {
	printf("Enter 1 for encryption, 2 for decryption: ");
	printf("Enter message: ");
	
	return 0;
}

// Encrypt a message based on transpose-13 algorithm
void encrypt(char message[], char result[]){
}

// Decrypt a message based on transpose-13 algorithm
void decrypt(char message[], char result[]){
}