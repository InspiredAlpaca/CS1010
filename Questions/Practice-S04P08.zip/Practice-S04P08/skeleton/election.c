// CS1010 AY2015/6 Semester 1
// PE1 Ex1: election.c
// Name: 
// Matriculation number: 
// plab-id: 
// Discussion group: 
// Description: 

#include <stdio.h>

int main(void) {
	 float sampleCountA=0.0, sampleCountB=0.0;
	 
	 // Use the following printf statements to print the appropriate messages.
	 printf("Enter number of voters in the division: ");

	 printf("Enter number of stations: ");
 
 	 printf("Enter number of voters in station"); // Incomplete
		 
	 printf("Enter number of votes for Team A: ");
		 
	 printf("Enter number of votes for Team B: ");
	 
     printf("Sample count for Team A = %.2f%%\n",sampleCountA*100);
     printf("Sample count for Team B = %.2f%%\n",sampleCountB*100);
	 
     return 0;
}

// Remove extra comments (including this one) after you have completed the program