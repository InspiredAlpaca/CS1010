// sumDigits.c
#include <stdio.h>

int main(void) {
	int sum;

	printf("Enter input: ");

	printf("Sum = %d\n", sum);

	return 0;
}

