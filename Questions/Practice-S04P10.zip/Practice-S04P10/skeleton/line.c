// CS1010 AY2015/6 Semester 2 PE1 Ex1
//
// line.c
//
// Name: 
// Matriculation number: 
// plab-id: 
// Discussion group: 
// Description: 

#include <stdio.h>

int main(void) {

	printf("Enter the coordinates of A: ");	 
	printf("Enter the coordinates of B: ");	
	printf("Enter the coordinates of C: ");
	printf("Enter the coordinates of D: ");
	 
	return 0;
}

//	Use the following statements for printing 
//	the output message in printMessage().
//	printf("The two lines are parallel.\n");
//	printf("The two lines are intersecting.\n");
//	printf("The two lines are overlapping.\n");