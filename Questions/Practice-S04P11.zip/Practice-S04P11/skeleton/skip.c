// CS1010 AY2015/6 Semester 2 PE1 Ex2
//
// skip.c
//
// Name: 
// Matriculation number: 
// plab-id: 
// Discussion group: 
// Description: 

#include <stdio.h>

int skipCount(int, int, int);

int main(void){
	int startPos, endPos, lower, upper;
	
	// Insert appropriate statements for reading the inputs.
	printf("Enter starting position: ");
	printf("Enter lower bound and upper bound: ");
	
	endPos = skipCount(startPos, lower, upper);
	
	printf("The ending position is %d.\n", endPos);
	
	return 0;
}

int skipCount(int startPos, int lower, int upper){
	return 0;  // stub
}


