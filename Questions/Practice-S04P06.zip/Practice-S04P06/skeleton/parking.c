// CS1010 AY2014/5 Semester 1
// PE1 Ex1: parking.c
// Name: 
// Matriculation number: 
// plab-id: 
// Discussion group: 
// Description: 

int main(void){
	int day, timeIn, timeOut;
	double fee;

	printf("Enter day: ");

	printf("Enter time-in: ");

	printf("Enter time-out: ");

	printf("Parking fee is $%.2f.\n", fee);

	return 0;
}
